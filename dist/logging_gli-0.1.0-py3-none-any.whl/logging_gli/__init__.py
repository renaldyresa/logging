from .src import LoggingGLI

log = LoggingGLI(withLogKey=False)

__all__ = [
    "LoggingGLI",
    "log"
]
